'use client'

import dynamic from 'next/dynamic'

const PekerjaanTiangPage = dynamic(() => import('./PekerjaanTiangPage'), {
  ssr: false,
})

export default function Page() {
  return <PekerjaanTiangPage />
}
